# lesbos-std
Please see the original: [goboscript/std](https://github.com/goboscript/std)
